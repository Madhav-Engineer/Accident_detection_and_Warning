import serial
from time import sleep

# Serial connection to Neo-7M
ser = serial.Serial("/dev/ttyS0", baudrate=9600, timeout=0.5)

try:
    while True:
        data = ser.readline().decode("utf-8").strip()
        if data.startswith('$GPGGA'):
            print("GPS Data:", data)
            # Extract and process GPS data as needed

        sleep(1)

except KeyboardInterrupt:
    ser.close()
